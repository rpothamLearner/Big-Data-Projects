### Feature Generation Instructions ###
The code folder contains following subfolders:
1. postgresqlCode
2. scalaCode
3. javaCode
4. pythonCode

1. Create Mimic Database using the following POSTGRES
1.1 create database and user
CREATE USER mimic with password 'postgres';
ALTER USER mimic superuser;
CREATE DATABASE mimic OWNER mimic;

1.2 create tables
$ psql -f C:\code\postgresCode\mimic-code\buildmimic\postgres\postgres_create_tables.sql -U mimic

1.3 load data
$ psql -f C:\code\postgresCode\mimic-code\buildmimic\postgres\postgres_load_data.sql -U mimic -v mimic_data_dir="C:\Users\zhang\Desktop\cse6250\project\mimic_data"

1.4 add indexes
$ psql -f C:\code\postgresCode\mimic-code\buildmimic\postgres\postgres_add_indexes.sql -U mimic

1.5 add constraints
$ psql -f C:\code\postgresCode\mimic-code\buildmimic\postgres\postgres_add_constraints.sql -U mimic

1.6 create ventdurations, bloodgasfirstday, and bloodgasfirstdayarterial tables and uofirstday, ventfirstday, vitalsfirstday, gcsfirstday, labsfirstday, echodata views
$ psql -f C:\code\postgresCode\mimic-code\concepts\durations\ventilation-durations.sql -U mimic
$ psql -f C:\code\postgresCode\mimic-code\concepts\firstday\blood-gas-first-day.sql -U mimic
$ psql -f C:\code\postgresCode\mimic-code\concepts\firstday\blood-gas-first-day-arterial.sql -U mimic
$ psql -f C:\code\postgresCode\mimic-code\concepts\firstday\urine-output-first-day.sql -U mimic
$ psql -f C:\code\postgresCode\mimic-code\concepts\firstday\ventilateion-first-day.sql -U mimic
$ psql -f C:\code\postgresCode\mimic-code\concepts\firstday\vitals-first-day.sql -U mimic
$ psql -f C:\code\postgresCode\mimic-code\concepts\firstday\gcs-first-day.sql -U mimic
$ psql -f C:\code\postgresCode\mimic-code\concepts\firstday\labs-first-day.sql -U mimic
$ psql -f C:\code\postgresCode\mimic-code\concepts\lecho-data.sql -U mimic

1.7 Generate the severity scores and comorbidities
1.7.1 create the SAPSII, Comorbidities, and SOFA views
$ psql -f C:\code\postgresCode\mimic-code\concepts\severitysocres\sapsii.sql -U mimic
$ psql -f C:\code\postgresCode\mimic-code\concepts\comorbidity\elixhauser-ahrq-v37-with-drg.sql -U mimic
$ psql -f C:\code\postgresCode\mimic-code\concepts\severitysocres\sofa.sql -U mimic

1.7.2 Generate the SAPSII, SOFA, Comorbidities features in .CSV format from POSTGRES tables
$ \COPY (SELECT * FROM sapsii) TO 'C:\code\scalaCode\data\SAPSII.csv' DELIMITER ',' CSV HEADER;
$ \COPY (SELECT * FROM ELIXHAUSER_AHRQ) TO 'C:\code\scalaCode\data\EHCOMORBIDITIES.csv'  DELIMITER ',' CSV HEADER;
$ \COPY (SELECT * FROM SOFA) TO 'C:\code\scalaCode\data\SOFA.csv'  DELIMITER ',' CSV HEADER;

2. Run scala code for feature generation
2.1 Follow the docker start up instruction from the website: http://www.sunlab.org/teaching/cse6250/spring2018/lab/environment/
2.2 Start docker and type following commands
    $ docker container start bigbox
    $ docker attach bigbox
2.3 start services required for the script running
    $ ./scripts/start-services
2.4 Run the feature generation code, the output is in folder code/feature_values_output
	$ cd C:/code/scalaCode/
    $ sbt/sbt compile run
    $ mkdir C:/code/feature_values_output
    $ mkdir C:/code/feature_values_output_csv
    $ cp C:/code/scalaCode/features_values/part* C:/code/feature_values_output

3. Run the java code for converting feature txt file to csv files
3.1 Open IDE and run Application.java from C:/code/javaCode/IdeaProjects/ParseFeatures/src/mn
3.2 Merge all the csv files into one single csv file
    $ cat C:/code/feature_values_output_csv/*.txt > C:/code/feature_values_output_csv/feature_value.txt

4. Run the following command to add masks/binary features for the sparse feature values. (python version: 2.7)
   $ cd C:/code/feature_values_output_csv/
   $ python add_mask_column.py
   The output file is C:/code/feature_value_with_masks.txt



### Setup Instructions ###
1. Clone the mimic3-benchmarks repository using the command git clone https://github.com/YerevaNN/mimic3-benchmarks.git 
2. Complete steps 2 - 6 on the repository's website.
3. Complete step 7 by running the command: python scripts/create_in_hospital_mortality.py data/root/ data/in-hospital-mortality/
4. Split training/testing sets using the command python mimic3models/split_train_val.py in-hospital-mortality
5. Run the Chart_DNN_And_NormalFeature_NN IPython notebook
6. Assign data/root/train to train_path and data/root/test to test_path
7. 'data/root/' is where you want to save the 'phenotype_train.csv' and 'phenotype_test.csv'
    7.1.1 If you want to extract the phenotype feature run "#### phenotype extraction cell"
    7.1.2 If you want to directly use the phenotype feature set already created run "#### load pre-extracted phenotype scores". This loads the above 2 .csv files (recommended)
8. Set the phenotype_features path to the feature ???
9. Set the features_without_chart_path to the feature results folder 'features_exclude_chart' @mengnan_files
10. Set the features_with_only_chart_path maps to the feature results folder 'features_only_chart' @mengnan_files
11. Run the Combined_ChartDNN_NormFNN notebook 
    11.1 Set phenotype_features path to /inputs/
    11.2 Set feature_chart_normf path to the feature results folder 'all_features' @mengnan_files

### Extract LSTM Results (optional) ###
0. Set your Python environment to use Anaconda 2
1. From /inputs, copy master_listfile.csv /data/in-hospital-mortality
2. Update /mimic3-benchmarks/mimic3models/in_hospital_mortality/main to use '/train' and 'master_listfile.csv' on line 156  
3. From /mimic3-benchmarks/mimic3models/in_hospital_mortality run the command: python -u main.py --network ../common_keras_models/lstm.py --mode test --load_state 
4. Run /code/extract_icustay_id.sh <path_to_predictions> <path_to_training_set> /inputs/icustays.csv
5. Run the Join_Labels notebook. 


import pandas as pd
import numpy as np

# df = pd.DataFrame({'CloseDelta':[np.nan,-0.5,0.5],
#                    'B':[0,1,0]})
df = pd.read_csv("feature_value.txt", sep = ",", header = None)
columns = len(list(df))
# print columns
# print df[1657]
def f(x):
    if (pd.isnull(x)):
        return 1
    else:
        return 0 

#print df
for i in range(columns):
	#print i
	if (i == 0) or (i == 51) :
		continue
	else:
		df[columns + i] = df[i].apply(f)

df.to_csv("feature_value_with_masks.txt", index = False, header = False)


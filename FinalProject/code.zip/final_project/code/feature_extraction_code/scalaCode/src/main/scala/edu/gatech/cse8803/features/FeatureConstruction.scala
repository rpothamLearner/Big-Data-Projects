/**
 * @author Hang Su
 */
package edu.gatech.cse8803.features

import edu.gatech.cse8803.model._
import org.apache.spark.SparkContext
import org.apache.spark.mllib.linalg.{Vector, Vectors}
import org.apache.spark.rdd.RDD
import org.apache.spark.SparkContext._


object FeatureConstruction {

  /**
   * ((patient-id, feature-name), feature-value)
   */
  type FeatureTuple = ((String, String), Double)
  def constructvalvularDiseaseFeatureTuple(icu_comorbidities_valvularDisease: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_valvularDisease_label = icu_comorbidities_valvularDisease.map(p => ((p._2, "valvularDisease"), p._3))
    icu_comorbidities_valvularDisease_label
  }
  def constructpulmonaryCirculationFeatureTuple(icu_comorbidities_pulmonaryCirculation: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_pulmonaryCirculation_label = icu_comorbidities_pulmonaryCirculation.map(p => ((p._2, "pulmonaryCirculation"), p._3))
    icu_comorbidities_pulmonaryCirculation_label
  }
  def constructperipheralVascularFeatureTuple(icu_comorbidities_peripheralVascular: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_peripheralVascular_label = icu_comorbidities_peripheralVascular.map(p => ((p._2, "peripheralVascular"), p._3))
    icu_comorbidities_peripheralVascular_label
  }
  def constructhypertensionFeatureTuple(icu_comorbidities_hypertension: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_hypertension_label = icu_comorbidities_hypertension.map(p => ((p._2, "hypertension"), p._3))
    icu_comorbidities_hypertension_label
  }
  def constructparalysisFeatureTuple(icu_comorbidities_paralysis: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_paralysis_label = icu_comorbidities_paralysis.map(p => ((p._2, "paralysis"), p._3))
    icu_comorbidities_paralysis_label
  }
  def constructotherNeurologicalFeatureTuple(icu_comorbidities_otherNeurological: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_otherNeurological_label = icu_comorbidities_otherNeurological.map(p => ((p._2, "otherNeurological"), p._3))
    icu_comorbidities_otherNeurological_label
  }
  def constructchronicPulmonaryFeatureTuple(icu_comorbidities_chronicPulmonary: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_chronicPulmonary_label = icu_comorbidities_chronicPulmonary.map(p => ((p._2, "chronicPulmonary"), p._3))
    icu_comorbidities_chronicPulmonary_label
  }
  def constructdiabetesUncomplicatedFeatureTuple(icu_comorbidities_diabetesUncomplicated: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_diabetesUncomplicated_label = icu_comorbidities_diabetesUncomplicated.map(p => ((p._2, "diabetesUncomplicated"), p._3))
    icu_comorbidities_diabetesUncomplicated_label
  }
  def constructdiabetesComplicatedFeatureTuple(icu_comorbidities_diabetesComplicated: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_diabetesComplicated_label = icu_comorbidities_diabetesComplicated.map(p => ((p._2, "diabetesComplicated"), p._3))
    icu_comorbidities_diabetesComplicated_label
  }
  def constructhypothyroidismFeatureTuple(icu_comorbidities_hypothyroidism: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_hypothyroidism_label = icu_comorbidities_hypothyroidism.map(p => ((p._2, "hypothyroidism"), p._3))
    icu_comorbidities_hypothyroidism_label
  }
  def constructrenalFailureFeatureTuple(icu_comorbidities_renalFailure: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_renalFailure_label = icu_comorbidities_renalFailure.map(p => ((p._2, "renalFailure"), p._3))
    icu_comorbidities_renalFailure_label
  }
  def constructliverDiseaseFeatureTuple(icu_comorbidities_liverDisease: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_liverDisease_label = icu_comorbidities_liverDisease.map(p => ((p._2, "liverDisease"), p._3))
    icu_comorbidities_liverDisease_label
  }
  def constructpepticUlcerFeatureTuple(icu_comorbidities_pepticUlcer: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_pepticUlcer_label = icu_comorbidities_pepticUlcer.map(p => ((p._2, "pepticUlcer"), p._3))
    icu_comorbidities_pepticUlcer_label
  }
  def constructaidsFeatureTuple(icu_comorbidities_aids: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_aids_label = icu_comorbidities_aids.map(p => ((p._2, "aids"), p._3))
    icu_comorbidities_aids_label
  }
  def constructlymphomaFeatureTuple(icu_comorbidities_lymphoma: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_lymphoma_label = icu_comorbidities_lymphoma.map(p => ((p._2, "lymphoma"), p._3))
    icu_comorbidities_lymphoma_label
  }
  def constructmetastaticCancerFeatureTuple(icu_comorbidities_metastaticCancer: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_metastaticCancer_label = icu_comorbidities_metastaticCancer.map(p => ((p._2, "metastaticCancer"), p._3))
    icu_comorbidities_metastaticCancer_label
  }
  def constructsolidTumorFeatureTuple(icu_comorbidities_solidTumor: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_solidTumor_label = icu_comorbidities_solidTumor.map(p => ((p._2, "solidTumor"), p._3))
    icu_comorbidities_solidTumor_label
  }
  def constructrheumatoidArthritisFeatureTuple(icu_comorbidities_rheumatoidArthritis: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_rheumatoidArthritis_label = icu_comorbidities_rheumatoidArthritis.map(p => ((p._2, "rheumatoidArthritis"), p._3))
    icu_comorbidities_rheumatoidArthritis_label
  }
  def constructcoagulopathyFeatureTuple(icu_comorbidities_coagulopathy: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_coagulopathy_label = icu_comorbidities_coagulopathy.map(p => ((p._2, "coagulopathy"), p._3))
    icu_comorbidities_coagulopathy_label
  }
  def constructobesityFeatureTuple(icu_comorbidities_obesity: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_obesity_label = icu_comorbidities_obesity.map(p => ((p._2, "obesity"), p._3))
    icu_comorbidities_obesity_label
  }
  def constructweightLossFeatureTuple(icu_comorbidities_weightLoss: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_weightLoss_label = icu_comorbidities_weightLoss.map(p => ((p._2, "weightLoss"), p._3))
    icu_comorbidities_weightLoss_label
  }
  def constructfluidElectrolyteFeatureTuple(icu_comorbidities_fluidElectrolyte: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_fluidElectrolyte_label = icu_comorbidities_fluidElectrolyte.map(p => ((p._2, "fluidElectrolyte"), p._3))
    icu_comorbidities_fluidElectrolyte_label
  }
  def constructbloodLossAnemiaFeatureTuple(icu_comorbidities_bloodLossAnemia: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_bloodLossAnemia_label = icu_comorbidities_bloodLossAnemia.map(p => ((p._2, "bloodLossAnemia"), p._3))
    icu_comorbidities_bloodLossAnemia_label
  }  
  def constructdeficiencyAnemiasFeatureTuple(icu_comorbidities_deficiencyAnemias: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_deficiencyAnemias_label = icu_comorbidities_deficiencyAnemias.map(p => ((p._2, "deficiencyAnemias"), p._3))
    icu_comorbidities_deficiencyAnemias_label
  }
  def constructalcoholAbuseFeatureTuple(icu_comorbidities_alcoholAbuse: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_alcoholAbuse_label = icu_comorbidities_alcoholAbuse.map(p => ((p._2, "alcoholAbuse"), p._3))
    icu_comorbidities_alcoholAbuse_label
  }
  def constructdrugAbuseFeatureTuple(icu_comorbidities_drugAbuse: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_drugAbuse_label = icu_comorbidities_drugAbuse.map(p => ((p._2, "drugAbuse"), p._3))
    icu_comorbidities_drugAbuse_label
  }
  def constructpsychosesFeatureTuple(icu_comorbidities_psychoses: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_psychoses_label = icu_comorbidities_psychoses.map(p => ((p._2, "psychoses"), p._3))
    icu_comorbidities_psychoses_label
  }
  def constructdepressionFeatureTuple(icu_comorbidities_depression: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_depression_label = icu_comorbidities_depression.map(p => ((p._2, "depression"), p._3))
    icu_comorbidities_depression_label
  }
  
  def constructcardiacArrhythmiasFeatureTuple(icu_comorbidities_cardiacArrhythmias: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_cardiacArrhythmias_label = icu_comorbidities_cardiacArrhythmias.map(p => ((p._2, "congestiveHeartFailure"), p._3))
    icu_comorbidities_cardiacArrhythmias_label
  }


  def constructcongestiveHeartFailureFeatureTuple(icu_comorbidities_congestiveHeartFailure: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_comorbidities_congestiveHeartFailure_label = icu_comorbidities_congestiveHeartFailure.map(p => ((p._2, "cardiacArrhythmias"), p._3))
    icu_comorbidities_congestiveHeartFailure_label
  }


  def construcMortalityFeatureTuple(mortality: RDD[(String, String, Double)]): RDD[FeatureTuple] = {
    val icu_mortality_tupe = mortality.map(p => ((p._2, "mortality"), p._3))
    icu_mortality_tupe
  }
    
  def constructPatientAgeFeatureTuple(patient_age_mortality: RDD[Patient_age_mortality]): RDD[FeatureTuple] = {
    val patient_age_tuple = patient_age_mortality.map(p => ((p.icuID, "age"), p.age))
    patient_age_tuple
  }
     
  def constructDiagnosticFeatureTuple(diagnostic: RDD[Diagnostic]): RDD[FeatureTuple] = {
    val icu_diagnostic = diagnostic.map(p => ((p.icuID, "diagnostic_count"), 1.0)).keyBy(p => p._1).reduceByKey((x, y) => (x._1, x._2 + y._2)).map(p => p._2)
    icu_diagnostic
  }
  def constructLabResultsFeatureTuple(labResult: RDD[(String, String, String)]): RDD[FeatureTuple] = {
    val icu_labResult = labResult.map(p => ((p._2, "AbnormalLabCount"), 1.0)).keyBy(p => p._1).reduceByKey((x, y) => (x._1, x._2 + y._2)).map(p => p._2)
    icu_labResult
  }

  def constructMedicationFeatureTuple(medication: RDD[Medication]): RDD[FeatureTuple] = {
    val icu_med = medication.map(p => ((p.icuID, "medication_count"), 1.0)).keyBy(p => p._1).reduceByKey((x,y) => (x._1, x._2 + y._2)).map(p => p._2)
    icu_med
  }

  def constructChartFeatureTuple(chart: RDD[Chart]): RDD[FeatureTuple] = {
    val icu_chart = chart.keyBy(p => (p.icuID, p.itemid))
         .reduceByKey((t1, t2) => if (t1.chartDate.before(t2.chartDate)) t2 else t1)
         .map(p => ((p._2.icuID, p._2.itemid), p._2.chartValue))
    icu_chart
  }

   def construct_icu_sapii_sapsScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_sapsScore = saps.map(p => ((p.icuID, "sapsScore"), p.sapsScore))
    icu_sapii_sapsScore
  }

  def construct_icu_sapii_scoreProbability_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_scoreProbability = saps.map(p => ((p.icuID, "scoreProbability"), p.scoreProbability))
    icu_sapii_scoreProbability
  }

  def construct_icu_sapii_ageScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_ageScore = saps.map(p => ((p.icuID, "ageScore"), p.ageScore))
    icu_sapii_ageScore
  }

  def construct_icu_sapii_hrScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_hrScore = saps.map(p => ((p.icuID, "hrScore"), p.hrScore))
    icu_sapii_hrScore
  }

  def construct_icu_sapii_sysbpScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_sysbpScore = saps.map(p => ((p.icuID, "sysbpScore"), p.sysbpScore))
    icu_sapii_sysbpScore
  }

  def construct_icu_sapii_tempScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_tempScore = saps.map(p => ((p.icuID, "tempScore"), p.tempScore))
    icu_sapii_tempScore
  }

  def construct_icu_sapii_pao2fio2Score_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_pao2fio2Score = saps.map(p => ((p.icuID, "pao2fio2Score"), p.pao2fio2Score))
    icu_sapii_pao2fio2Score
  }

  def construct_icu_sapii_uoScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_uoScore = saps.map(p => ((p.icuID, "uoScore"), p.uoScore))
    icu_sapii_uoScore
  }

  def construct_icu_sapii_bunScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_bunScore = saps.map(p => ((p.icuID, "bunScore"), p.bunScore))
    icu_sapii_bunScore
  }

  def construct_icu_sapii_wbcScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_wbcScore = saps.map(p => ((p.icuID, "wbcScore"), p.wbcScore))
    icu_sapii_wbcScore
  }

  def construct_icu_sapii_potassiumScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_potassiumScore = saps.map(p => ((p.icuID, "potassiumScore"), p.potassiumScore))
    icu_sapii_potassiumScore
  }

  def construct_icu_sapii_sodiumScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_sodiumScore = saps.map(p => ((p.icuID, "sodiumScore"), p.sodiumScore))
    icu_sapii_sodiumScore
  }
  def construct_icu_sapii_bicarbonateScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_bicarbonateScore = saps.map(p => ((p.icuID, "bicarbonateScore"), p.bicarbonateScore))
    icu_sapii_bicarbonateScore
  }

  def construct_icu_sapii_bilirubinScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_bilirubinScore = saps.map(p => ((p.icuID, "bilirubinScore"), p.bilirubinScore))
    icu_sapii_bilirubinScore
  }

  def construct_icu_sapii_gcsScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_gcsScore = saps.map(p => ((p.icuID, "gcsScore"), p.gcsScore))
    icu_sapii_gcsScore
  }

  def construct_icu_sapii_comorbidityScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_comorbidityScore = saps.map(p => ((p.icuID, "comorbidityScore"), p.comorbidityScore))
    icu_sapii_comorbidityScore
  }

  def construct_icu_sapii_admissiontypeScore_FeatureTuple(saps: RDD[Saps2]): RDD[FeatureTuple] = {
    val icu_sapii_admissiontypeScore = saps.map(p => ((p.icuID, "admissiontypeScore"), p.admissiontypeScore))
    icu_sapii_admissiontypeScore
  }
  def construct_icu_sofa_respiration_FeatureTuple(sofa:RDD[Sofa]): RDD[FeatureTuple] = {
    val icu_sofa_respiration = sofa.map(p => ((p.icuID, "respiration"), p.respiration))
    icu_sofa_respiration
  }
  def construct_icu_sofa_coagulation_FeatureTuple(sofa:RDD[Sofa]): RDD[FeatureTuple] = {
    val icu_sofa_coagulation = sofa.map(p => ((p.icuID, "coagulation"), p.coagulation))
    icu_sofa_coagulation
  }
  def construct_icu_sofa_liver_FeatureTuple(sofa:RDD[Sofa]): RDD[FeatureTuple] = {
    val icu_sofa_liver = sofa.map(p => ((p.icuID, "liver"), p.liver))
    icu_sofa_liver
  }
  def construct_icu_sofa_cardiovascular_FeatureTuple(sofa:RDD[Sofa]): RDD[FeatureTuple] = {
    val icu_sofa_cardiovascular = sofa.map(p => ((p.icuID, "cardiovascular"), p.cardiovascular))
    icu_sofa_cardiovascular
  }
  def construct_icu_sofa_cns_FeatureTuple(sofa:RDD[Sofa]): RDD[FeatureTuple] = {
    val icu_sofa_cns = sofa.map(p => ((p.icuID, "cns"), p.cns))
    icu_sofa_cns
  }
  def construct_icu_sofa_renal_FeatureTuple(sofa:RDD[Sofa]): RDD[FeatureTuple] = {
    val icu_sofa_renal = sofa.map(p => ((p.icuID, "renal"), p.renal))
    icu_sofa_renal
  }  
  def construct_icu_sofa_sofa_FeatureTuple(sofa:RDD[Sofa]): RDD[FeatureTuple] = {
    val icu_sofa_sofa = sofa.map(p => ((p.icuID, "sofa"), p.sofa))
    icu_sofa_sofa
  }
  def construct_icu_LOS_FeatureTuple(IcuStays: RDD[IcuStays]): RDD[FeatureTuple] = {
    val icu_LOS = IcuStays.map(p => ((p.icuID, "LOS"), p.los))
    icu_LOS
  }

  def construct(sc: SparkContext, feature: RDD[FeatureTuple]): RDD[(String, Vector)] = {
    /** save for later usage */
    //feature.cache()

    /** create a feature name to id map*/
    val feature_index_name = sc.broadcast(feature.map(p => p._1._2).distinct().zipWithIndex().collectAsMap())
    println(feature.map(p => p._1._2).distinct().zipWithIndex().collectAsMap())
    val result = feature.map(p => (p._1._1, feature_index_name.value(p._1._2), p._2)).groupBy(_._1).map( p => {
      val feature_list = p._2.map(p => (p._2.toInt, p._3)).toList
      (p._1, Vectors.sparse(feature_index_name.value.size, feature_list))
    })

    result
   }

}



/**
 * @author Hang Su <hangsu@gatech.edu>.
 */

package edu.gatech.cse8803.model

import java.sql.Date

/** Data Model Classes **/

case class Patient(patientID: String, sex: String, dob: Date, dod: Date, isDead: Double)

case class Lab(patientID: String, hadmID: String, flag: String)

case class IcuStays(patientID: String, hadmID: String, icuID: String, inDate: Date, outDate: Date, los: Double, first_careunit: String, last_careunit: String)

case class Chart(patientID: String, icuID: String, itemid: String, chartDate: Date, chartValue: Double)

case class Medication(patientID: String, icuID: String, medicine: String)

case class Saps2(patientID: String, icuID: String, sapsScore: Double, scoreProbability: Double, ageScore: Double,
                 hrScore: Double, sysbpScore: Double, tempScore: Double, pao2fio2Score: Double, uoScore: Double,
                 bunScore: Double, wbcScore: Double, potassiumScore: Double, sodiumScore: Double,
                 bicarbonateScore: Double, bilirubinScore: Double, gcsScore: Double, comorbidityScore:
                 Double, admissiontypeScore: Double)
case class Sofa(patientID: String, icuID: String, sofa: Double, respiration: Double, coagulation: Double, liver: Double, cardiovascular: Double, cns: Double, renal: Double)

case class Diagnostic(patientID: String, icuID: String, icd9code: String)
case class Phenotype(patientID: String, icuID: String, phenotype: String)
case class Mortality(patientID: String, icuID: String, mortality: Double)
case class Patient_age_mortality(icuID: String, age: Double, mortality_inunit: Double)



case class Comorbidities(patientID: String, hadmID: String, congestiveHeartFailure: Double,
                         cardiacArrhythmias: Double, valvularDisease: Double, pulmonaryCirculation: Double,
                         peripheralVascular: Double, hypertension: Double, paralysis: Double, otherNeurological: Double,
                         chronicPulmonary: Double, diabetesUncomplicated: Double, diabetesComplicated: Double,
                         hypothyroidism: Double, renalFailure: Double, liverDisease: Double, pepticUlcer: Double,
                         aids: Double, lymphoma: Double, metastaticCancer: Double, solidTumor: Double)
case class Comorbidities2(patientID: String, hadmID: String, rheumatoidArthritis: Double, coagulopathy: Double, obesity: Double, weightLoss: Double,
                         fluidElectrolyte: Double, bloodLossAnemia: Double, deficiencyAnemias: Double,
                         alcoholAbuse: Double, drugAbuse: Double, psychoses: Double, depression: Double)
//**/
//case class LabResult(patientID: String, hadmID: String, date: Date, labName: String, value: Double)




//case class Note(patientID: String, hadmID: String, chartDate: Date, category: String, description: String, text: String)


/**
 * @author Mengnan Zhang <mzhang326@gatech.edu>.
 */

package edu.gatech.cse8803.main

import java.text.SimpleDateFormat


import edu.gatech.cse8803.features.FeatureConstruction
import edu.gatech.cse8803.ioutils.CSVUtils
import edu.gatech.cse8803.model._
import org.apache.spark.SparkContext._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.SparkContext
import org.apache.spark.mllib.linalg.{Vector, Vectors}
import java.sql.Date
import java.text.SimpleDateFormat
import scala.io.Source
import java.io.File
import org.apache.spark.sql.functions._
import org.apache.spark.sql._


object Main {
  def main(args: Array[String]) {

    import org.apache.log4j.Logger
    import org.apache.log4j.Level

    Logger.getLogger("org").setLevel(Level.WARN)
    Logger.getLogger("akka").setLevel(Level.WARN)

    val sc = createContext
    val sqlContext= new org.apache.spark.sql.SQLContext(sc)
	import sqlContext.implicits._

    /** initialize loading fo data */
    val (patient, icustays, chart, medication, saps, diagnostics, phenotype, patient_age_mortality, comorbidities, comorbidities2, labResults, sofa) = loadRddRawData(sqlContext)
    // create mortality RDD
/*    val mappedPatient = patient.map(p => (p.patientID, p.isDead))
    val mappedICUStay = icustays.map(p => (p.patientID, p.icuID))
    val icu_mortality = mappedPatient.join(mappedICUStay).map(p => (p._1, p._2._2, p._2._1))*/
    val mappedICUStay = icustays.map(p => (p.icuID, p.patientID))
    val icustay_mortality = patient_age_mortality.map(p => (p.icuID, p.mortality_inunit))
    val icu_mortality = mappedICUStay.join(icustay_mortality).map(p => (p._2._1, p._1, p._2._2))
    //icu_mortality.take(5).foreach(println)
    
    val mappedICUID_hadmid = icustays.map(p => (p.hadmID, p.icuID))
    // create lab abnormal count feature RDD
    val labResults_hadmid = labResults.filter(_.flag == "abnormal").map(p => (p.hadmID, p.flag))
    val icu_labResults = mappedICUID_hadmid.join(labResults_hadmid).map(p => (p._1, p._2._1, p._2._2))
    //icu_labResults.take(5).foreach(println)
    val icu_labResults_label = FeatureConstruction.constructLabResultsFeatureTuple(icu_labResults)
    // create congestiveHeartFailure RDD
    val congestiveHeartFailure_hadmid = comorbidities.map(p => (p.hadmID, p.congestiveHeartFailure))
    val icu_comorbidities_congestiveHeartFailure = mappedICUID_hadmid.join(congestiveHeartFailure_hadmid).map(p => (p._1, p._2._1, p._2._2))
    val icu_comorbidities_congestiveHeartFailure_label = FeatureConstruction.constructcongestiveHeartFailureFeatureTuple(icu_comorbidities_congestiveHeartFailure)

	// cardiacArrhythmias RDD
    val cardiacArrhythmias_hadmid = comorbidities.map(p => (p.hadmID, p.cardiacArrhythmias))
    val icu_comorbidities_cardiacArrhythmias = mappedICUID_hadmid.join(cardiacArrhythmias_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_cardiacArrhythmias_label = FeatureConstruction.constructcardiacArrhythmiasFeatureTuple(icu_comorbidities_cardiacArrhythmias)
	// valvularDisease
    val valvularDisease_hadmid = comorbidities.map(p => (p.hadmID, p.valvularDisease))
    val icu_comorbidities_valvularDisease = mappedICUID_hadmid.join(valvularDisease_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_valvularDisease_label = FeatureConstruction.constructvalvularDiseaseFeatureTuple(icu_comorbidities_valvularDisease)


	// pulmonaryCirculation
    val pulmonaryCirculation_hadmid = comorbidities.map(p => (p.hadmID, p.pulmonaryCirculation))
    val icu_comorbidities_pulmonaryCirculation = mappedICUID_hadmid.join(pulmonaryCirculation_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_pulmonaryCirculation_label = FeatureConstruction.constructpulmonaryCirculationFeatureTuple(icu_comorbidities_pulmonaryCirculation)

	// peripheralVascular
    val peripheralVascular_hadmid = comorbidities.map(p => (p.hadmID, p.peripheralVascular))
    val icu_comorbidities_peripheralVascular = mappedICUID_hadmid.join(peripheralVascular_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_peripheralVascular_label = FeatureConstruction.constructperipheralVascularFeatureTuple(icu_comorbidities_peripheralVascular)


	// hypertension
    val hypertension_hadmid = comorbidities.map(p => (p.hadmID, p.hypertension))
    val icu_comorbidities_hypertension = mappedICUID_hadmid.join(hypertension_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_hypertension_label = FeatureConstruction.constructhypertensionFeatureTuple(icu_comorbidities_hypertension)


	///paralysis
    val paralysis_hadmid = comorbidities.map(p => (p.hadmID, p.paralysis))
    val icu_comorbidities_paralysis = mappedICUID_hadmid.join(paralysis_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_paralysis_label = FeatureConstruction.constructparalysisFeatureTuple(icu_comorbidities_paralysis)

	///otherNeurological
    val otherNeurological_hadmid = comorbidities.map(p => (p.hadmID, p.otherNeurological))
    val icu_comorbidities_otherNeurological = mappedICUID_hadmid.join(otherNeurological_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_otherNeurological_label = FeatureConstruction.constructotherNeurologicalFeatureTuple(icu_comorbidities_otherNeurological)

	///chronicPulmonary
    val chronicPulmonary_hadmid = comorbidities.map(p => (p.hadmID, p.chronicPulmonary))
    val icu_comorbidities_chronicPulmonary = mappedICUID_hadmid.join(chronicPulmonary_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_chronicPulmonary_label = FeatureConstruction.constructchronicPulmonaryFeatureTuple(icu_comorbidities_chronicPulmonary)

	///diabetesUncomplicated
    val diabetesUncomplicated_hadmid = comorbidities.map(p => (p.hadmID, p.diabetesUncomplicated))
    val icu_comorbidities_diabetesUncomplicated = mappedICUID_hadmid.join(diabetesUncomplicated_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_diabetesUncomplicated_label = FeatureConstruction.constructdiabetesUncomplicatedFeatureTuple(icu_comorbidities_diabetesUncomplicated)


	///diabetesComplicated
    val diabetesComplicated_hadmid = comorbidities.map(p => (p.hadmID, p.diabetesComplicated))
    val icu_comorbidities_diabetesComplicated = mappedICUID_hadmid.join(diabetesComplicated_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_diabetesComplicated_label = FeatureConstruction.constructdiabetesComplicatedFeatureTuple(icu_comorbidities_diabetesComplicated)

	///hypothyroidism
    val hypothyroidism_hadmid = comorbidities.map(p => (p.hadmID, p.hypothyroidism))
    val icu_comorbidities_hypothyroidism = mappedICUID_hadmid.join(hypothyroidism_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_hypothyroidism_label = FeatureConstruction.constructhypothyroidismFeatureTuple(icu_comorbidities_hypothyroidism)



	///renalFailure
    val renalFailure_hadmid = comorbidities.map(p => (p.hadmID, p.renalFailure))
    val icu_comorbidities_renalFailure = mappedICUID_hadmid.join(renalFailure_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_renalFailure_label = FeatureConstruction.constructrenalFailureFeatureTuple(icu_comorbidities_renalFailure)



	///liverDisease
    val liverDisease_hadmid = comorbidities.map(p => (p.hadmID, p.liverDisease))
    val icu_comorbidities_liverDisease = mappedICUID_hadmid.join(liverDisease_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_liverDisease_label = FeatureConstruction.constructliverDiseaseFeatureTuple(icu_comorbidities_liverDisease)


	//pepticUlcer
    val pepticUlcer_hadmid = comorbidities.map(p => (p.hadmID, p.pepticUlcer))
    val icu_comorbidities_pepticUlcer = mappedICUID_hadmid.join(pepticUlcer_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_pepticUlcer_label = FeatureConstruction.constructpepticUlcerFeatureTuple(icu_comorbidities_pepticUlcer)


	//aids
    val aids_hadmid = comorbidities.map(p => (p.hadmID, p.aids))
    val icu_comorbidities_aids = mappedICUID_hadmid.join(aids_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_aids_label = FeatureConstruction.constructaidsFeatureTuple(icu_comorbidities_aids)


	//lymphoma
    val lymphoma_hadmid = comorbidities.map(p => (p.hadmID, p.lymphoma))
    val icu_comorbidities_lymphoma = mappedICUID_hadmid.join(lymphoma_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_lymphoma_label = FeatureConstruction.constructlymphomaFeatureTuple(icu_comorbidities_lymphoma)


	///metastaticCancer
    val metastaticCancer_hadmid = comorbidities.map(p => (p.hadmID, p.metastaticCancer))
    val icu_comorbidities_metastaticCancer = mappedICUID_hadmid.join(metastaticCancer_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_metastaticCancer_label = FeatureConstruction.constructmetastaticCancerFeatureTuple(icu_comorbidities_metastaticCancer)

	///solidTumor
	val solidTumor_hadmid = comorbidities.map(p => (p.hadmID, p.solidTumor))
    val icu_comorbidities_solidTumor = mappedICUID_hadmid.join(solidTumor_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_solidTumor_label = FeatureConstruction.constructsolidTumorFeatureTuple(icu_comorbidities_solidTumor)

	//rheumatoidArthritis
	val rheumatoidArthritis_hadmid = comorbidities2.map(p => (p.hadmID, p.rheumatoidArthritis))
    val icu_comorbidities_rheumatoidArthritis = mappedICUID_hadmid.join(rheumatoidArthritis_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_rheumatoidArthritis_label = FeatureConstruction.constructrheumatoidArthritisFeatureTuple(icu_comorbidities_rheumatoidArthritis)


	//coagulopathy
	val coagulopathy_hadmid = comorbidities2.map(p => (p.hadmID, p.coagulopathy))
    val icu_comorbidities_coagulopathy = mappedICUID_hadmid.join(coagulopathy_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_coagulopathy_label = FeatureConstruction.constructcoagulopathyFeatureTuple(icu_comorbidities_coagulopathy)

	//obesity
	val obesity_hadmid = comorbidities2.map(p => (p.hadmID, p.obesity))
    val icu_comorbidities_obesity = mappedICUID_hadmid.join(obesity_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_obesity_label = FeatureConstruction.constructobesityFeatureTuple(icu_comorbidities_obesity)


	//weightLoss
	val weightLoss_hadmid = comorbidities2.map(p => (p.hadmID, p.weightLoss))
    val icu_comorbidities_weightLoss = mappedICUID_hadmid.join(weightLoss_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_weightLoss_label = FeatureConstruction.constructweightLossFeatureTuple(icu_comorbidities_weightLoss)


	//fluidElectrolyte
	val fluidElectrolyte_hadmid = comorbidities2.map(p => (p.hadmID, p.fluidElectrolyte))
    val icu_comorbidities_fluidElectrolyte = mappedICUID_hadmid.join(fluidElectrolyte_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_fluidElectrolyte_label = FeatureConstruction.constructfluidElectrolyteFeatureTuple(icu_comorbidities_fluidElectrolyte)
	//bloodLossAnemia
	val bloodLossAnemia_hadmid = comorbidities2.map(p => (p.hadmID, p.bloodLossAnemia))
    val icu_comorbidities_bloodLossAnemia_hadmid = mappedICUID_hadmid.join(bloodLossAnemia_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_bloodLossAnemia_hadmid_label = FeatureConstruction.constructbloodLossAnemiaFeatureTuple(icu_comorbidities_bloodLossAnemia_hadmid)


	//deficiencyAnemias
	val deficiencyAnemias_hadmid = comorbidities2.map(p => (p.hadmID, p.deficiencyAnemias))
    val icu_comorbidities_deficiencyAnemias_hadmid = mappedICUID_hadmid.join(deficiencyAnemias_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_deficiencyAnemias_hadmid_label = FeatureConstruction.constructdeficiencyAnemiasFeatureTuple(icu_comorbidities_deficiencyAnemias_hadmid)


	//alcoholAbuse
	val alcoholAbuse_hadmid = comorbidities2.map(p => (p.hadmID, p.alcoholAbuse))
    val icu_comorbidities_alcoholAbuse_hadmid = mappedICUID_hadmid.join(alcoholAbuse_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_alcoholAbuse_hadmid_label = FeatureConstruction.constructalcoholAbuseFeatureTuple(icu_comorbidities_alcoholAbuse_hadmid)

	//drugAbuse
	val drugAbuse_hadmid = comorbidities2.map(p => (p.hadmID, p.drugAbuse))
    val icu_comorbidities_drugAbuse_hadmid = mappedICUID_hadmid.join(drugAbuse_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_drugAbuse_hadmid_label = FeatureConstruction.constructdrugAbuseFeatureTuple(icu_comorbidities_drugAbuse_hadmid)
	//psychoses
	val psychoses_hadmid = comorbidities2.map(p => (p.hadmID, p.psychoses))
    val icu_comorbidities_psychoses_hadmid = mappedICUID_hadmid.join(psychoses_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_psychoses_hadmid_label = FeatureConstruction.constructpsychosesFeatureTuple(icu_comorbidities_psychoses_hadmid)


	//depression
	val depression_hadmid = comorbidities2.map(p => (p.hadmID, p.depression))
    val icu_comorbidities_depression_hadmid = mappedICUID_hadmid.join(depression_hadmid).map(p => (p._1, p._2._1, p._2._2))	
	val icu_comorbidities_depression_hadmid_label = FeatureConstruction.constructdepressionFeatureTuple(icu_comorbidities_depression_hadmid)



	val icu_diagnostic_features = FeatureConstruction.constructDiagnosticFeatureTuple(diagnostics)
	val icu_medication_features = FeatureConstruction.constructMedicationFeatureTuple(medication)  	
	val icu_chart_features = FeatureConstruction.constructChartFeatureTuple(chart)
	val icu_sapii_sapsScore = FeatureConstruction.construct_icu_sapii_sapsScore_FeatureTuple(saps)
	val icu_sapii_scoreProbability = FeatureConstruction.construct_icu_sapii_scoreProbability_FeatureTuple(saps)
	val icu_sapii_ageScore = FeatureConstruction.construct_icu_sapii_ageScore_FeatureTuple(saps)
	val icu_sapii_hrScore = FeatureConstruction.construct_icu_sapii_hrScore_FeatureTuple(saps)
	val icu_sapii_sysbpScore = FeatureConstruction.construct_icu_sapii_sysbpScore_FeatureTuple(saps)
	val icu_sapii_tempScore = FeatureConstruction.construct_icu_sapii_tempScore_FeatureTuple(saps)
	val icu_sapii_pao2fio2Score = FeatureConstruction.construct_icu_sapii_pao2fio2Score_FeatureTuple(saps)
	val icu_sapii_uoScore = FeatureConstruction.construct_icu_sapii_uoScore_FeatureTuple(saps)
	val icu_sapii_bunScore = FeatureConstruction.construct_icu_sapii_bunScore_FeatureTuple(saps)
	val icu_sapii_wbcScore = FeatureConstruction.construct_icu_sapii_wbcScore_FeatureTuple(saps)
	val icu_sapii_potassiumScore = FeatureConstruction.construct_icu_sapii_potassiumScore_FeatureTuple(saps)
	val icu_sapii_sodiumScore = FeatureConstruction.construct_icu_sapii_sodiumScore_FeatureTuple(saps)
	val icu_sapii_bicarbonateScore = FeatureConstruction.construct_icu_sapii_bicarbonateScore_FeatureTuple(saps)
	val icu_sapii_bilirubinScore = FeatureConstruction.construct_icu_sapii_bilirubinScore_FeatureTuple(saps)
	val icu_sapii_gcsScore = FeatureConstruction.construct_icu_sapii_gcsScore_FeatureTuple(saps)
	val icu_sapii_comorbidityScore = FeatureConstruction.construct_icu_sapii_comorbidityScore_FeatureTuple(saps)
	val icu_sapii_admissiontypeScore = FeatureConstruction.construct_icu_sapii_admissiontypeScore_FeatureTuple(saps)
    val icu_mortality_label = FeatureConstruction.construcMortalityFeatureTuple(icu_mortality)
    val icu_los = FeatureConstruction.construct_icu_LOS_FeatureTuple(icustays)
    val icu_age = FeatureConstruction.constructPatientAgeFeatureTuple(patient_age_mortality)
    val icu_sofa_sofa = FeatureConstruction.construct_icu_sofa_sofa_FeatureTuple(sofa)
    val icu_sofa_respiration = FeatureConstruction.construct_icu_sofa_respiration_FeatureTuple(sofa)
    val icu_sofa_coagulation = FeatureConstruction.construct_icu_sofa_coagulation_FeatureTuple(sofa)
    val icu_sofa_liver = FeatureConstruction.construct_icu_sofa_liver_FeatureTuple(sofa)
    val icu_sofa_cardiovascular = FeatureConstruction.construct_icu_sofa_cardiovascular_FeatureTuple(sofa)
    val icu_sofa_cns = FeatureConstruction.construct_icu_sofa_cns_FeatureTuple(sofa)
    val icu_sofa_renal = FeatureConstruction.construct_icu_sofa_renal_FeatureTuple(sofa)

    // all features included
	val feature_tuples = sc.union(icu_sofa_sofa, icu_sofa_renal, icu_sofa_cns, icu_sofa_cardiovascular, icu_sofa_liver, icu_sofa_coagulation, icu_sofa_respiration, icu_labResults_label, icu_comorbidities_valvularDisease_label, icu_comorbidities_pulmonaryCirculation_label, icu_comorbidities_peripheralVascular_label, icu_comorbidities_hypertension_label, icu_comorbidities_paralysis_label, icu_comorbidities_otherNeurological_label, icu_comorbidities_chronicPulmonary_label, icu_comorbidities_diabetesUncomplicated_label, icu_comorbidities_diabetesComplicated_label, icu_comorbidities_hypothyroidism_label, icu_comorbidities_renalFailure_label, icu_comorbidities_liverDisease_label, icu_comorbidities_pepticUlcer_label, icu_comorbidities_aids_label, icu_comorbidities_lymphoma_label, icu_comorbidities_metastaticCancer_label, icu_comorbidities_solidTumor_label, icu_comorbidities_rheumatoidArthritis_label, icu_comorbidities_coagulopathy_label, icu_comorbidities_obesity_label, icu_comorbidities_weightLoss_label, icu_comorbidities_fluidElectrolyte_label, icu_comorbidities_bloodLossAnemia_hadmid_label, icu_comorbidities_deficiencyAnemias_hadmid_label, icu_comorbidities_alcoholAbuse_hadmid_label, icu_comorbidities_drugAbuse_hadmid_label, icu_comorbidities_psychoses_hadmid_label, icu_comorbidities_depression_hadmid_label, icu_comorbidities_cardiacArrhythmias_label, icu_comorbidities_congestiveHeartFailure_label, icu_age, icu_los, icu_mortality_label, icu_diagnostic_features, icu_medication_features, icu_chart_features, icu_sapii_sapsScore, icu_sapii_scoreProbability, icu_sapii_ageScore, icu_sapii_hrScore, icu_sapii_sysbpScore, icu_sapii_tempScore, icu_sapii_pao2fio2Score, icu_sapii_uoScore, icu_sapii_bunScore, icu_sapii_wbcScore, icu_sapii_potassiumScore, icu_sapii_sodiumScore, icu_sapii_bicarbonateScore, icu_sapii_bilirubinScore, icu_sapii_gcsScore, icu_sapii_comorbidityScore, icu_sapii_admissiontypeScore)
    // exclude chart events features
    //val feature_tuples = sc.union(icu_sofa_sofa, icu_sofa_renal, icu_sofa_cns, icu_sofa_cardiovascular, icu_sofa_liver, icu_sofa_coagulation, icu_sofa_respiration, icu_labResults_label, icu_comorbidities_valvularDisease_label, icu_comorbidities_pulmonaryCirculation_label, icu_comorbidities_peripheralVascular_label, icu_comorbidities_hypertension_label, icu_comorbidities_paralysis_label, icu_comorbidities_otherNeurological_label, icu_comorbidities_chronicPulmonary_label, icu_comorbidities_diabetesUncomplicated_label, icu_comorbidities_diabetesComplicated_label, icu_comorbidities_hypothyroidism_label, icu_comorbidities_renalFailure_label, icu_comorbidities_liverDisease_label, icu_comorbidities_pepticUlcer_label, icu_comorbidities_aids_label, icu_comorbidities_lymphoma_label, icu_comorbidities_metastaticCancer_label, icu_comorbidities_solidTumor_label, icu_comorbidities_rheumatoidArthritis_label, icu_comorbidities_coagulopathy_label, icu_comorbidities_obesity_label, icu_comorbidities_weightLoss_label, icu_comorbidities_fluidElectrolyte_label, icu_comorbidities_bloodLossAnemia_hadmid_label, icu_comorbidities_deficiencyAnemias_hadmid_label, icu_comorbidities_alcoholAbuse_hadmid_label, icu_comorbidities_drugAbuse_hadmid_label, icu_comorbidities_psychoses_hadmid_label, icu_comorbidities_depression_hadmid_label, icu_comorbidities_cardiacArrhythmias_label, icu_comorbidities_congestiveHeartFailure_label, icu_age, icu_los, icu_mortality_label, icu_diagnostic_features, icu_medication_features, icu_sapii_sapsScore, icu_sapii_scoreProbability, icu_sapii_ageScore, icu_sapii_hrScore, icu_sapii_sysbpScore, icu_sapii_tempScore, icu_sapii_pao2fio2Score, icu_sapii_uoScore, icu_sapii_bunScore, icu_sapii_wbcScore, icu_sapii_potassiumScore, icu_sapii_sodiumScore, icu_sapii_bicarbonateScore, icu_sapii_bilirubinScore, icu_sapii_gcsScore, icu_sapii_comorbidityScore, icu_sapii_admissiontypeScore)
    // only include chart events features
    //val feature_tuples = sc.union(icu_mortality_label, icu_chart_features)
    val rawFeatures = FeatureConstruction.construct(sc, feature_tuples)
      //rawFeatures.saveAsTextFile("mimic_output.txt")
      rawFeatures.saveAsTextFile("feature_values")
      sc.stop 
    }


  def loadRddRawData(sqlContext: SQLContext): (RDD[Patient], RDD[IcuStays], RDD[Chart], RDD[Medication], RDD[Saps2], RDD[Diagnostic], RDD[Phenotype], RDD[Patient_age_mortality], RDD[Comorbidities], RDD[Comorbidities2], RDD[Lab], RDD[Sofa]) = {
    val dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

    // load patient data
    List("data/PATIENTS.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))
    val patient = sqlContext.sql(
      """
        |SELECT SUBJECT_ID, GENDER, DOB, DOD, EXPIRE_FLAG
        |FROM PATIENTS
      """.stripMargin)
      .map(r => Patient(r(0).toString, 
                        r(1).toString, 
                        new Date(dateFormat.parse(r(2).toString).getTime),
                        if (r(4).toString.toInt == 1 && r(3).toString.trim != "")
                          new Date(dateFormat.parse(r(3).toString).getTime)
                        else
                          new Date(dateFormat.parse("9000-01-01 00:00:00").getTime),
                        r(4).toString.toDouble))
    
    //load ICU stay data
    List("data/ICUSTAYS.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))

    val icustays = sqlContext.sql(
      """
        |SELECT SUBJECT_ID, HADM_ID, ICUSTAY_ID, INTIME, OUTTIME, LOS, FIRST_CAREUNIT, LAST_CAREUNIT
        |FROM ICUSTAYS
      """.stripMargin)
      .map(r => IcuStays(
        r(0).toString,
        r(1).toString,
        r(2).toString,
        if (r(3).toString.isEmpty)
          new Date(dateFormat.parse("9000-01-01 00:00:00").getTime)
        else
          new Date(dateFormat.parse(r(3).toString).getTime),
        if (r(4).toString.isEmpty)
          new Date(dateFormat.parse("9000-01-01 00:00:00").getTime)
        else
          new Date(dateFormat.parse(r(4).toString).getTime),
      	if (r(5).toString.isEmpty) 0.0 else r(5).toString.toDouble,
      	r(6).toString,
      	r(7).toString
      ))




    //load chart data
    List("data/CHARTEVENTS.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))

    val chart = sqlContext.sql(
      """
        |SELECT SUBJECT_ID, ICUSTAY_ID, ITEMID, CHARTTIME, VALUENUM

        |FROM CHARTEVENTS
      """.stripMargin)
      .map(r => Chart(
        r(0).toString,
        r(1).toString,
        r(2).toString,
        new Date(dateFormat.parse(r(3).toString).getTime),
        if (r(4).toString.isEmpty) 0.0 else r(4).toString.toDouble
      ))

    // load lab data
    List("data/LABEVENTS.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))

    val labResults = sqlContext.sql(
      """
        |SELECT SUBJECT_ID, HADM_ID, FLAG
        |FROM LABEVENTS
      """.stripMargin)
      .map(r => Lab(
        r(0).toString,
        r(1).toString,
        r(2).toString
      ))

    // load diagnostic data
    List("data/all_diagnoses.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))

    val diagnostics = sqlContext.sql(
      """
        |SELECT SUBJECT_ID, ICUSTAY_ID, ICD9_CODE
        |FROM all_diagnoses
      """.stripMargin)
      .map(r => Diagnostic(
        r(0).toString,
        r(1).toString,
        r(2).toString
      ))
    //load age data
    List("data/all_stays.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))

    val patient_age_mortality = sqlContext.sql(
      """
        |SELECT ICUSTAY_ID, AGE, MORTALITY_INHOSPITAL
        |FROM all_stays
      """.stripMargin)
      .map(r => Patient_age_mortality(
        r(0).toString,
        r(1).toString.toDouble,
        r(2).toString.toDouble
      ))    
 
    // load medication data
    List("data/PRESCRIPTIONS.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))

    val medications = sqlContext.sql(
      """
        |SELECT SUBJECT_ID, ICUSTAY_ID, DRUG
        |FROM PRESCRIPTIONS
      """.stripMargin)
      .map(r => Medication(
        r(0).toString,
        r(1).toString,
        r(2).toString
      ))


    // load sapsii data
    List("data/SAPSII.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))

    val saps = sqlContext.sql(
      """
        |SELECT subject_id, hadm_id, icustay_id, sapsii, sapsii_prob, age_score,hr_score,sysbp_score,temp_score,
        |pao2fio2_score,uo_score,bun_score,wbc_score,potassium_score,sodium_score,bicarbonate_score,
        |bilirubin_score,gcs_score,comorbidity_score,admissiontype_score
        |FROM SAPSII
      """.stripMargin)
      .map(r => Saps2(
      	r(0).toString,
        r(2).toString,
        if (r(3).toString.isEmpty) 0.0 else r(3).toString.toDouble,
        if (r(4).toString.isEmpty) 0.0 else r(4).toString.toDouble,
        if (r(5).toString.isEmpty) 0.0 else r(5).toString.toDouble,
        if (r(6).toString.isEmpty) 0.0 else r(6).toString.toDouble,
        if (r(7).toString.isEmpty) 0.0 else r(7).toString.toDouble,
        if (r(8).toString.isEmpty) 0.0 else r(8).toString.toDouble,
        if (r(9).toString.isEmpty) 0.0 else r(9).toString.toDouble,
        if (r(10).toString.isEmpty) 0.0 else r(10).toString.toDouble,
        if (r(11).toString.isEmpty) 0.0 else r(11).toString.toDouble,
        if (r(12).toString.isEmpty) 0.0 else r(12).toString.toDouble,
        if (r(13).toString.isEmpty) 0.0 else r(13).toString.toDouble,
        if (r(14).toString.isEmpty) 0.0 else r(14).toString.toDouble,
        if (r(15).toString.isEmpty) 0.0 else r(15).toString.toDouble,
        if (r(16).toString.isEmpty) 0.0 else r(16).toString.toDouble,
        if (r(17).toString.isEmpty) 0.0 else r(17).toString.toDouble,
        if (r(18).toString.isEmpty) 0.0 else r(18).toString.toDouble,
        if (r(19).toString.isEmpty) 0.0 else r(19).toString.toDouble
      ))
    // load SOFA data
    List("data/SOFA.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))

    val sofa = sqlContext.sql(
      """
        |SELECT subject_id, hadm_id, icustay_id, sofa, respiration, coagulation, liver, cardiovascular, cns, renal
        |FROM SOFA
      """.stripMargin)
      .map(r => Sofa(
      	r(0).toString,
        r(2).toString,
        if (r(3).toString.isEmpty) 0.0 else r(3).toString.toDouble,
        if (r(4).toString.isEmpty) 0.0 else r(4).toString.toDouble,
        if (r(5).toString.isEmpty) 0.0 else r(5).toString.toDouble,
        if (r(6).toString.isEmpty) 0.0 else r(6).toString.toDouble,
        if (r(7).toString.isEmpty) 0.0 else r(7).toString.toDouble,
        if (r(8).toString.isEmpty) 0.0 else r(8).toString.toDouble,
        if (r(9).toString.isEmpty) 0.0 else r(9).toString.toDouble
      ))
      
    // load phenotype data
    List("data/all_diagnoses.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))

    val phenotype = sqlContext.sql(
      """
        |SELECT SUBJECT_ID, ICUSTAY_ID, LONG_TITLE
        |FROM all_diagnoses
      """.stripMargin)
      .map(r => Phenotype(
        r(0).toString,
        r(1).toString,
        r(2).toString
      ))


 
    // load Comorbidities Data
    List("data/EHCOMORBIDITIES.csv")
      .foreach(CSVUtils.loadCSVAsTable(sqlContext, _))

    val comorbidities = sqlContext.sql(
      """
        |SELECT subject_id,hadm_id,congestive_heart_failure,cardiac_arrhythmias,valvular_disease,
        |pulmonary_circulation,peripheral_vascular,hypertension,paralysis,other_neurological,
        |chronic_pulmonary,diabetes_uncomplicated,diabetes_complicated,hypothyroidism,renal_failure,
        |liver_disease,peptic_ulcer,aids,lymphoma,metastatic_cancer,solid_tumor
        |FROM EHCOMORBIDITIES
      """.stripMargin)
      .map(r => Comorbidities(
        r(0).toString,
        r(1).toString,
        if (r(2).toString.isEmpty) 0.0 else r(3).toString.toDouble,
        if (r(3).toString.isEmpty) 0.0 else r(3).toString.toDouble,
        if (r(4).toString.isEmpty) 0.0 else r(4).toString.toDouble,
        if (r(5).toString.isEmpty) 0.0 else r(5).toString.toDouble,
        if (r(6).toString.isEmpty) 0.0 else r(6).toString.toDouble,
        if (r(7).toString.isEmpty) 0.0 else r(7).toString.toDouble,
        if (r(8).toString.isEmpty) 0.0 else r(8).toString.toDouble,
        if (r(9).toString.isEmpty) 0.0 else r(9).toString.toDouble,
        if (r(10).toString.isEmpty) 0.0 else r(10).toString.toDouble,
        if (r(11).toString.isEmpty) 0.0 else r(11).toString.toDouble,
        if (r(12).toString.isEmpty) 0.0 else r(12).toString.toDouble,
        if (r(13).toString.isEmpty) 0.0 else r(13).toString.toDouble,
        if (r(14).toString.isEmpty) 0.0 else r(14).toString.toDouble,
        if (r(15).toString.isEmpty) 0.0 else r(15).toString.toDouble,
        if (r(16).toString.isEmpty) 0.0 else r(16).toString.toDouble,
        if (r(17).toString.isEmpty) 0.0 else r(17).toString.toDouble,
        if (r(18).toString.isEmpty) 0.0 else r(18).toString.toDouble,
        if (r(19).toString.isEmpty) 0.0 else r(19).toString.toDouble,
        if (r(20).toString.isEmpty) 0.0 else r(20).toString.toDouble
      ))
    val comorbidities_part2 = sqlContext.sql(
      """
        |SELECT subject_id,hadm_id,rheumatoid_arthritis,
        |coagulopathy,obesity,weight_loss,fluid_electrolyte,blood_loss_anemia,deficiency_anemias,
        |alcohol_abuse,drug_abuse,psychoses,depression
        |FROM EHCOMORBIDITIES
      """.stripMargin)
      .map(r => Comorbidities2(
        r(0).toString,
        r(1).toString,
        if (r(2).toString.isEmpty) 0.0 else r(3).toString.toDouble,
        if (r(3).toString.isEmpty) 0.0 else r(3).toString.toDouble,
        if (r(4).toString.isEmpty) 0.0 else r(4).toString.toDouble,
        if (r(5).toString.isEmpty) 0.0 else r(5).toString.toDouble,
        if (r(6).toString.isEmpty) 0.0 else r(6).toString.toDouble,
        if (r(7).toString.isEmpty) 0.0 else r(7).toString.toDouble,
        if (r(8).toString.isEmpty) 0.0 else r(8).toString.toDouble,
        if (r(9).toString.isEmpty) 0.0 else r(9).toString.toDouble,
        if (r(10).toString.isEmpty) 0.0 else r(10).toString.toDouble,
        if (r(11).toString.isEmpty) 0.0 else r(11).toString.toDouble,
        if (r(12).toString.isEmpty) 0.0 else r(12).toString.toDouble
      ))
    (patient, icustays, chart, medications, saps, diagnostics, phenotype, patient_age_mortality, comorbidities, comorbidities_part2, labResults, sofa)
    
   }

  def createContext(appName: String, masterUrl: String): SparkContext = {
    val conf = new SparkConf().setAppName(appName).setMaster(masterUrl)
    new SparkContext(conf)
  }

  def createContext(appName: String): SparkContext = createContext(appName, "local")

  def createContext: SparkContext = createContext("CSE 8803 Homework Two Application", "local")
}

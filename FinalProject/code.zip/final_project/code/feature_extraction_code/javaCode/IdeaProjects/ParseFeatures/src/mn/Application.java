package mn;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.*;

public class Application {

    public static void main(String[] args) {

        File folder = new File("C:\\Ucode\\feature_values_output\\");

        String results = "";
        int columnCount = -1;
        int fileCount = 0;
        int writeFileCount = 0;

        for (final File fileEntry : folder.listFiles()) {
            System.out.println(fileEntry.getPath());
            try (Scanner s = new Scanner(fileEntry)) { // try-with-resources
                fileCount++;
                while (s.hasNext()) {
                    String currentString = s.next();
                    // get the ID
                    String id = currentString.substring(1,currentString.indexOf(','));
                    if (columnCount < 0) {
                        String columnCountSubString = currentString.substring(currentString.indexOf(',')+2);
                        columnCount = Integer.parseInt(columnCountSubString.substring(0,columnCountSubString.indexOf(','))) - 1;
                    }
                    String arraySubStrings = currentString.substring(currentString.indexOf('[')+1);

                    // get the keys and values then put them into a hash map
                    String[] keys = arraySubStrings.substring(0,arraySubStrings.indexOf(']')).split(",");
                    String[] values = arraySubStrings.substring(arraySubStrings.indexOf('[')+1, arraySubStrings.length()-3).split(",");
                    Map<Integer, String> keyValuePair = new HashMap<>();
                    for (int i=0; i<keys.length; i++) {
                        keyValuePair.put(Integer.parseInt(keys[i]),values[i]);
                    }

                    // build the result row then add to results
                    String resultRow = id + ",";
                    for (int i=0; i<columnCount + 1; i++) {
                        if (keyValuePair.containsKey(i)) {
                            resultRow += keyValuePair.get(i);
                        }
                        if (i < columnCount) {
                            resultRow += ",";
                        }
                    }
                    results += resultRow + '\n';
                }
            } catch (Exception e) {
                System.out.println("Error! :: \n" + e.getMessage());
            }
            if (fileCount == 30) {
                writeTheFile(results, "part" + writeFileCount + ".txt");
                writeFileCount++;
                fileCount = 0;
                results = "";
            }
        }
        if (results.length() > 0) {
            writeTheFile(results, "part" + writeFileCount + ".txt");
        }
    }

    private static void writeTheFile(String results, String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\code\\feature_values_output_csv\\" + fileName))) {
            writer.write(results);

        } catch (Exception e) {
            System.out.println("ERROR WRITING FILE");
            System.out.println(e.getMessage());
            System.out.println(e);
        }
    }

}